#PPS "A031"
r1, r2 = map(int, input().split())
print(r1*r2 -1)