#PPS "A034"
arr = {int(input()) % 42 for _ in range(10)}
print(len(arr))
